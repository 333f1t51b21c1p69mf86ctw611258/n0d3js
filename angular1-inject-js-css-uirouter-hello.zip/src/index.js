angular
  .module('app', ['ui.router']);
